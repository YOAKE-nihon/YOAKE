// --- 1. 必要なライブラリの読み込み ---
require("dotenv").config(); // .envファイルから環境変数を読み込む
const express = require("express");
const { createClient } = require("@supabase/supabase-js");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const cors = require("cors");
const axios = require("axios"); // LINEのIDトークン検証に必要
const line = require("@line/bot-sdk"); // LINE Messaging APIの操作に必要

const app = express();

// --- 2. ミドルウェアの設定 ---
// CORSを許可し、JSON形式のリクエストボディを扱えるようにする
app.use(cors());
app.use(express.json());

// --- 3. 外部サービス (Supabase, LINE) のクライアントを初期化 ---
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

const lineClient = new line.Client({
  channelAccessToken: process.env.LINE_MESSAGING_API_TOKEN,
});

// --- 4. APIエンドポイントの定義 ---

/**
 * @endpoint POST /api/register
 * @description LIFFアプリからの新規登録リクエストを処理する
 * @body { idToken: string, surveyData: object }
 */
app.post("/api/register", async (req, res) => {
  console.log("--- [/api/register] Received request from LIFF ---");
  const { idToken, surveyData } = req.body;
  if (!idToken || !surveyData) {
    return res
      .status(400)
      .json({
        success: false,
        message: "IDトークンまたはアンケートデータが不足しています。",
      });
  }

  try {
    // Step 1: LINEのIDトークンを検証し、LINEユーザー情報を取得
    const params = new URLSearchParams();
    params.append("id_token", idToken);
    params.append("client_id", process.env.LINE_LOGIN_CHANNEL_ID);
    const lineResponse = await axios.post(
      "https://api.line.me/oauth2/v2.1/verify",
      params,
      { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    );
    const lineProfile = lineResponse.data;
    const lineUserId = lineProfile.sub;
    console.log(`[LOG] LINE Token verified. LINE User ID: ${lineUserId}`);

    // Step 2: Supabase Authにユーザーが存在するか確認し、なければ作成
    let finalUser;
    const {
      data: { users },
      error: listError,
    } = await supabase.auth.admin.listUsers({ email: surveyData.email });
    if (listError) throw listError;
    if (users && users.length > 0) {
      finalUser = users[0];
      console.log(
        `[LOG] User with email ${surveyData.email} already exists. User ID: ${finalUser.id}`
      );
    } else {
      const {
        data: { user },
        error: createError,
      } = await supabase.auth.admin.createUser({
        email: surveyData.email,
        email_confirm: true,
        user_metadata: { name: lineProfile.name, picture: lineProfile.picture },
      });
      if (createError) throw createError;
      finalUser = user;
      console.log(`[LOG] New Supabase Auth user created: ${finalUser.id}`);
    }

    // Step 3: Stripeに顧客情報を作成
    const stripeCustomer = await stripe.customers.create({
      email: surveyData.email,
      name: lineProfile.name,
      metadata: { supabase_user_id: finalUser.id, line_user_id: lineUserId },
    });
    console.log(`[LOG] Stripe customer created: ${stripeCustomer.id}`);

    // Step 4: プロフィール情報とアンケート回答をDBに保存 (Upsert: 存在すれば更新、なければ新規作成)
    await supabase.from("profiles").upsert({
      id: finalUser.id,
      name: lineProfile.name,
      avatar_url: lineProfile.picture,
      line_user_id: lineUserId,
      email: surveyData.email,
      gender: surveyData.gender,
      birth_date: surveyData.birthDate,
      phone: surveyData.phone,
      experience_years: surveyData.experienceYears,
      industry: surveyData.industry,
      job_type: surveyData.jobType,
      stripe_customer_id: stripeCustomer.id,
      updated_at: new Date(),
    });
    console.log(`[LOG] Profile data upserted for: ${finalUser.id}`);

    await supabase
      .from("survey_responses")
      .upsert(
        { user_id: finalUser.id, ...surveyData },
        { onConflict: "user_id" }
      );
    console.log(`[LOG] Survey response upserted for: ${finalUser.id}`);

    // Step 5: 登録完了後、LINEにプッシュメッセージを送信して連携を促す
    try {
      const liffUrl = `https://liff.line.me/${process.env.LIFF_ID_LINKING}`;
      console.log(`[LOG] Sending push message to user: ${lineUserId}`);
      const message = {
        type: "template",
        altText: "アカウント連携のお願い",
        template: {
          type: "buttons",
          thumbnailImageUrl:
            "https://storage.googleapis.com/be-a-hero-images/thumbnail.jpg", // 例: 公開されている画像URL
          imageAspectRatio: "rectangle",
          imageSize: "cover",
          title: "会員登録ありがとうございます！",
          text: "サービスを最大限にご利用いただくため、最後にLINEアカウントとの連携をお願いします。",
          actions: [
            { type: "uri", label: "アカウント連携に進む", uri: liffUrl },
          ],
        },
      };
      await lineClient.pushMessage(lineUserId, [message]);
      console.log(`[LOG] Push message sent successfully.`);
    } catch (pushError) {
      console.error(
        "[SERVER WARNING] Failed to send push message:",
        pushError.originalError
          ? pushError.originalError.response.data
          : pushError.message
      );
    }

    // Step 6: フロントエンドに成功を通知
    res
      .status(201)
      .json({
        success: true,
        message: "ユーザー登録成功",
        stripeCustomerId: stripeCustomer.id,
      });
  } catch (error) {
    console.error(
      "[SERVER ERROR in /api/register]",
      error.response ? error.response.data : error.message
    );
    res
      .status(500)
      .json({
        success: false,
        message: "サーバー処理中にエラーが発生しました。",
      });
  }
});

/**
 * @endpoint POST /api/create-payment-intent
 * @description 決済処理の準備を行う
 * @body { amount: number, email: string, stripeCustomerId: string }
 */
app.post("/api/create-payment-intent", async (req, res) => {
  const { amount, email, stripeCustomerId } = req.body;
  if (!amount || !email || !stripeCustomerId) {
    return res
      .status(400)
      .json({
        success: false,
        message: "金額、メールアドレス、顧客IDは必須です。",
      });
  }
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: parseInt(amount),
      currency: "jpy",
      customer: stripeCustomerId,
    });
    res.send({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    console.error("[SERVER ERROR] Stripe PaymentIntent creation error:", error);
    res
      .status(500)
      .json({ success: false, message: "決済情報の作成に失敗しました。" });
  }
});

/**
 * @endpoint POST /api/link-line-account
 * @description アカウント連携LIFFから呼び出され、リッチメニューを会員用のものに切り替える
 * @body { email: string, lineUserId: string }
 */
app.post("/api/link-line-account", async (req, res) => {
  console.log("\n--- [/api/link-line-account] Received request ---");
  const { email, lineUserId } = req.body;
  const memberRichMenuId = process.env.RICH_MENU_ID_MEMBER;
  if (!email || !lineUserId || !memberRichMenuId) {
    return res
      .status(400)
      .json({
        success: false,
        message: "リクエストに必要な情報が不足しています。",
      });
  }

  try {
    // 1. LINE Messaging APIを呼び出して、リッチメニューをユーザーに紐付ける
    console.log(
      `[API CALL] Linking rich menu ${memberRichMenuId} to user ${lineUserId}...`
    );
    await lineClient.linkRichMenuToUser(lineUserId, memberRichMenuId);

    console.log(
      `[SUCCESS] Successfully linked member rich menu to user: ${lineUserId}`
    );
    res
      .status(200)
      .json({ success: true, message: "LINEアカウントの連携が完了しました。" });
  } catch (error) {
    console.error("\n❌ [/api/link-line-account] エラーが発生しました ❌");
    if (error.originalError) {
      // LINE Bot SDKのエラーの場合
      console.error("ステータスコード:", error.originalError.response.status);
      console.error(
        "エラー内容:",
        JSON.stringify(error.originalError.response.data, null, 2)
      );
    } else {
      console.error("予期せぬエラー:", error.message);
    }
    res
      .status(500)
      .json({
        success: false,
        message: "サーバー処理中にエラーが発生しました。",
      });
  }
});

// --- 5. サーバーの起動 ---
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
